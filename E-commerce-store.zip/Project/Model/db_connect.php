<?php

function db_connect(){
    $username = "lytro";  // MySQL username
    $password = "Lytro1997!";  // MySQL password
    $dsn = 'mysql:host=localhost;dbname=lytro';
    try{
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }catch(PDOException $message){
        echo "Connection failed: ". $message->getMessage();
        exit();
    }
}

function product_list(){
    $pdo = db_connect();
    $stmt = $pdo->query('SELECT * FROM product');
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $products;
}

function search_products(){
    $pdo = db_connect();
    $name = $_POST['name'];
    $partialName = "%" . $name . "%";
    $stmt = $pdo->prepare('SELECT * FROM product WHERE Name = :name 
    OR Name LIKE :partialName');
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':partialName', $partialName);
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $products;
}
function catalog_products($category) {
    $pdo = db_connect();
    
    if (empty($category)) {
        $stmt = $pdo->query('SELECT * FROM product');
    } else {
        $stmt = $pdo->prepare('SELECT * FROM product WHERE Category = :category');
        $stmt->bindParam(':category', $category);
        $stmt->execute();
    }
    
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $products;
}
function login() {
    session_start();
    $pdo = db_connect();
    $username = $_POST['username'];
    $password = $_POST['password'];

    $redirectToAdmin = $_POST['redirect']; //put the redirect value = admin from login page


    // Fetch the user from the database
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :username');
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (password_verify($password, $user['Password'])) {
            // Set session variables

            if ($user['Role'] === 'admin') {
                $_SESSION['User_ID'] = $user['User_ID'];
                $_SESSION['Role'] = $user['Role'];
                $_SESSION['Username'] = $user['Username'];
                $_SESSION['Email_Address'] = $user['Email_Address'];
                header('Location: index.php?action=admin&success=' . urlencode('Admin login successful.'));
            } elseif ($user['Role'] === 'user') {
                if ($redirectToAdmin == 'admin') {
                    // If the user tried to access the admin page but is not an admin
                    header("Location: index.php?action=login&error=" . urlencode("You do not have permission to access the admin panel."));
                } else {
                    // Regular user login
                    $_SESSION['User_ID'] = $user['User_ID'];
                    $_SESSION['Role'] = $user['Role'];
                    $_SESSION['Username'] = $user['Username'];
                    $_SESSION['Email_Address'] = $user['Email_Address'];
                    header('Location: index.php?action=userpage&success=' . urlencode('Login successful.'));
                }
            }
        } else {
            header('Location: index.php?action=login&error=' . urlencode('Password is incorrect.'));
        }
    } else {
        header('Location: index.php?action=login&error=' . urlencode('Username is incorrect.'));
    }
    exit();
}


function logout() {
    session_start(); // Start the session

    // Unset all of the session variables
    $_SESSION = array();

    // Destroy the session.
    session_destroy();

    // Redirect to homepage
    header('Location: index.php?action=homepage');
    exit();
}

function signup() {
    $pdo = db_connect();
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $role = 'user';

    // Check if username already exists
    $username_check = $pdo->prepare('SELECT 1 FROM users WHERE Username = :username');
    $username_check->bindParam(':username', $username);
    $username_check->execute();
    if ($username_check->fetch()) {
        header('Location: index.php?action=signup&error=' . urlencode('Username already exists.'));
        exit();
    }

    // Check if email already exists
    $email_check = $pdo->prepare('SELECT 1 FROM users WHERE Email_Address = :email');
    $email_check->bindParam(':email', $email);
    $email_check->execute();
    if ($email_check->fetch()) {
        header('Location: index.php?action=signup&error=' . urlencode('Email already exists.'));
        exit();
    }

    // Insert the new user into the database
    $stmt = $pdo->prepare('INSERT INTO users (Username, Password, Email_Address, Role) VALUES (:username, :password, :email, :role)');
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':role', $role);

    if ($stmt->execute()) {
        header('Location: index.php?action=signup&success=' . urlencode('User registered successfully!'));
    } else {
        header('Location: index.php?action=signup&error=' . urlencode('Failed to register user.'));
    }
    exit();
}
function addtocart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $pdo = db_connect();

    // Check if the user is logged in
    if (!isset($_SESSION['User_ID'])) {
        header('Location: index.php?action=login&error=' . urlencode('Please login to add items to cart.'));
        exit();
    }

    // Validate input data
    if (!isset($_POST['product_id'], $_POST['quantity'], $_POST['name'], $_POST['price'], $_POST['action_type'])) {
        header('Location: index.php?action=userpage&error=' . urlencode('Product or quantity is missing.'));
        exit();
    }

    // Sanitize and process input data
    $product_id = (int)$_POST['product_id'];
    $quantity = max(1, (int)$_POST['quantity']);
    $product_name = htmlspecialchars($_POST['name']);
    $product_price = (float)$_POST['price'];
    $transaction_type = $_POST['action_type']; // 'buy' or 'sell'

    // Check if the product is in stock
    $stmt = $pdo->prepare('SELECT Product_ID, Stock FROM product WHERE Product_ID = :product_id');
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product || $quantity > $product['Stock']) {
        header('Location: index.php?action=userpage&error=' . urlencode('Product not found or insufficient stock.'));
        exit();
    }

    // Adjust the price for 'sell' transaction type
    $product_price = ($transaction_type === 'sell') ? -abs($product_price) : abs($product_price);

    // Check if the item is already in the cart
    $item_found = false;
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['Product_ID'] === $product_id) {
                $item['Quantity'] += $quantity; // Update quantity
                $item_found = true;
                break;
            }
        }
    }

    // If the item is not in the cart, add it
    if (!$item_found) {
        $_SESSION['cart'][] = [
            'Product_ID' => $product_id,
            'Transaction_Type' => $transaction_type,
            'Quantity' => $quantity,
            'Name' => $product_name,
            'Price' => $product_price
        ];
    }

    // Recalculate totals
    calculate_cart_totals();

    header('Location: index.php?action=userpage&success=' . urlencode('Item added to cart!'));
    exit();
}

// Helper function to calculate cart totals
function calculate_cart_totals() {
    $total_quantity = 0;
    $total_price = 0.0;
    foreach ($_SESSION['cart'] as $item) {
        $total_quantity += $item['Quantity'];
        $total_price += $item['Price'] * $item['Quantity'];
    }
    $_SESSION['cart_totals'] = [
        'total_quantity' => $total_quantity,
        'total_price' => $total_price
    ];
}


function delete_item() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $product_id = (int)$_POST['product_id'];

    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['Product_ID'] === $product_id) {
                unset($_SESSION['cart'][$key]);
                break;
            }
        }
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex the array
    }

    calculate_cart_totals(); // Update totals
    header("Location: index.php?action=cart");
    exit();
}


function update_quantity() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $pdo = db_connect();

    $product_id = (int)$_POST['product_id'];
    $new_quantity = max(1, (int)$_POST['quantity']); // Ensure positive integer

    $stmt = $pdo->prepare('SELECT Stock FROM product WHERE Product_ID = :product_id');
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product && $new_quantity <= $product['Stock']) {
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['Product_ID'] === $product_id) {
                $item['Quantity'] = $new_quantity;
                break;
            }
        }
        calculate_cart_totals(); // Update totals
        header("Location: index.php?action=cart");
        exit();
    } else {
        header("Location: index.php?action=cart&error=" . urlencode("Invalid quantity or insufficient stock."));
        exit();
    }
}

function clear_cart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    unset($_SESSION['cart']);
    $_SESSION['cart_totals'] = [
        'total_quantity' => 0,
        'total_price' => 0.0
    ];
    header("Location: index.php?action=cart");
    exit();
}

function validateAddress() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $pdo = db_connect();
    date_default_timezone_set('America/Denver');
    // Retrieve and sanitize input data
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zipcode = $_POST['zipcode'];
    $userId = (int)$_SESSION['User_ID'];
    $quantity = (int)$_SESSION['cart_totals']['total_quantity'];
    $amount = (float)$_SESSION['cart_totals']['total_price'];
    $orderDate = date('Y-m-d');
    $fullAddress = "$address, $city, $state, $zipcode";

    // Handle transaction type
    $transactionTypes = implode(', ', array_column($_SESSION['cart'], 'Transaction_Type'));
    // Join product names into a string
    $productNames = implode(', ', array_column($_SESSION['cart'], 'Name'));

    // Corrected SQL statement with matching placeholders
    $stmt = $pdo->prepare('INSERT INTO `order` (User_ID, Quantity, Order_Date, Amount, Transaction_Type, Product_name, Address)
    VALUES (:User_ID, :Quantity, :Order_Date, :Amount, :Transaction_Type, :Product_name, :Address)');

    // Bind parameters to the prepared statement
    $stmt->bindParam(':User_ID', $userId, PDO::PARAM_INT);
    $stmt->bindParam(':Quantity', $quantity, PDO::PARAM_INT);
    $stmt->bindParam(':Order_Date', $orderDate);
    $stmt->bindParam(':Amount', $amount);
    $stmt->bindParam(':Transaction_Type', $transactionTypes); // Corrected to match the SQL placeholder
    $stmt->bindParam(':Product_name', $productNames);
    $stmt->bindParam(':Address', $fullAddress);

    // Execute the query and check if it is successful
    if ($stmt->execute()) {
        header("Location: index.php?action=shipment&success=" . urlencode("Your order has been placed successfully."));
        foreach ($_SESSION['cart'] as $item) {
            // Check if the action is "buy" or "sell"
            if ($item['Transaction_Type'] === 'buy') {
                // If "buy", decrease the stock
                $updateStmt = $pdo->prepare('UPDATE product SET Stock = Stock - :quantity WHERE Product_ID = :product_id');
            } elseif ($item['Transaction_Type'] === 'sell') {
                // If "sell", increase the stock
                $updateStmt = $pdo->prepare('UPDATE product SET Stock = Stock + :quantity WHERE Product_ID = :product_id');
            }

            // Bind parameters and execute the statement
            $updateStmt->bindParam(':quantity', $item['Quantity'], PDO::PARAM_INT);
            $updateStmt->bindParam(':product_id', $item['Product_ID'], PDO::PARAM_INT);
            $updateStmt->execute();
        }        // Clear the cart using the clear_cart() function
        clear_cart();
        
    } else {
        // Output error information
        $errorInfo = $stmt->errorInfo();
        echo "Error inserting into orders table: " . $errorInfo[2];
        exit();
    }
}

function getUserOrders($userId) {
    $pdo = db_connect();
    $stmt = $pdo->prepare('SELECT Order_ID, Product_name AS Product_Name, Quantity, Amount, Order_Date, Amount AS Total_Amount FROM `order` WHERE User_ID = :userId ORDER BY Order_ID DESC, Order_Date DESC');
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//admin function
function add_product() {
    $pdo = db_connect();
    $name = $_POST['name'];
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    //image
    $uploadDir = '../images/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create the directory if it doesn't exist
    }
    $uploadFile = $uploadDir . basename($_FILES['image']['name']);
    $imageFileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    $validExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $imagePath = null;  
    echo "Resolved path: " . realpath($uploadDir) . "<br>";

    
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        die("File upload error: " . $_FILES['image']['error']);
    }
    
    // Validate file type
    if (!in_array($imageFileType, $validExtensions)) {
        die("Invalid file type: " . $imageFileType);
    }
    
    // Validate temporary file
    if (!file_exists($_FILES['image']['tmp_name'])) {
        die("Temporary file not found: " . $_FILES['image']['tmp_name']);
    }
    
    // Move uploaded file to the target directory
    if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
        $imagePath = $uploadFile; // Save the uploaded file path
    } else {
        die("Failed to move uploaded file. Check permissions and destination path: " . $uploadFile);
    }

    $stmt = $pdo->prepare('INSERT INTO product (Name, Price, Stock, Category, Description, Image) VALUES (:name, :price, :stock, :category, :description, :image)');
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':stock', $stock);
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':image', $imagePath);

    if ($stmt->execute()) {
        header("Location: index.php?action=admin&success=" . urlencode("Product added successfully."));
    } else {
        header("Location: index.php?action=admin&error=" . urlencode("Failed to add product."));
    }
    exit();
}


function add_user() {
    $pdo = db_connect();
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $role = $_POST['role']; // Assume 'user' or 'admin'

    $stmt = $pdo->prepare('INSERT INTO users (Username, Password, Email_Address, Role) VALUES (:username, :password, :email, :role)');
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':role', $role);

    if ($stmt->execute()) {
        header("Location: index.php?action=admin&success=" . urlencode("User added successfully."));
    } else {
        header("Location: index.php?action=admin&error=" . urlencode("Failed to add user."));
    }
    exit();
}

function update_product() {
    $pdo = db_connect();
    $productId = (int)$_POST['product_id'];
    $name = $_POST['name'];
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock']; // Changed 'quantity' to 'stock'
    $category = $_POST['category'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare('UPDATE product SET Name = :name, Price = :price, Stock = :stock, Category = :category, Description = :description WHERE Product_ID = :product_id');
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':stock', $stock); // Updated to use 'stock'
    $stmt->bindParam(':category', $category);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: index.php?action=admin&success=" . urlencode("Product updated successfully."));
    } else {
        header("Location: index.php?action=admin&error=" . urlencode("Failed to update product."));
    }
    exit();
}


function delete_product() {
    $pdo = db_connect();
    $productId = (int)$_POST['product_id'];

    $stmt = $pdo->prepare('DELETE FROM product WHERE Product_ID = :product_id');
    $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header("Location: index.php?action=admin&success=" . urlencode("Product deleted successfully."));
    } else {
        header("Location: index.php?action=admin&error=" . urlencode("Failed to delete product."));
    }
    exit();
}

function view_orders() {
    $pdo = db_connect();
    $stmt = $pdo->query('SELECT * FROM `order` ORDER BY Order_Date DESC');
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $orders;
}

function view_customers() {
    $pdo = db_connect();
    $stmt = $pdo->query("SELECT User_ID, Username, Email_Address, Role FROM users 
    WHERE Role = 'user' ORDER BY Username ASC");
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $customers;
}
function view_products() {
    $pdo = db_connect();
    $stmt = $pdo->query('SELECT * FROM product ORDER BY Product_ID ASC');
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $products;
}

function get_product_by_id($product_id) {
    $pdo = db_connect();
    $stmt = $pdo->prepare('SELECT * FROM product WHERE Product_ID = :product_id');
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

?>