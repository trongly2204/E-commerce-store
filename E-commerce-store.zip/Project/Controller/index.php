<?php
// Include the database connection
include_once '../Model/db_connect.php';

// Get the action from GET or set a default value
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

// Handle the different actions using a switch statement
switch ($action) {
    case 'homepage':
        session_start();
        if (!isset($_SESSION['User_ID']) || !isset($_SESSION['Email_Address'])) {
            // User is not logged in, continue with normal homepage logic
            
            // Check if the form was submitted using POST
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                if (isset($_POST['action']) && $_POST['action'] === 'search') {
                    // Search by name
                    $name = $_POST['name'];
                    $products = search_products($name);
                } elseif (isset($_POST['action']) && $_POST['action'] === 'filter') {
                    // Filter by category
                    $category = $_POST['category'];
                    $products = catalog_products($category);
                } else {
                    // No search or category, show the main product listing
                    $products = product_list();
                }
            } else {
                // No form submission, show the main product listing
                $products = product_list();
            }
    
            include '../View/homepage.php';  // Load homepage view
        } else {
            // If the user is logged in, redirect to userpage
            header('Location: index.php?action=userpage');
            exit();
        }
        break;
    
    case 'userpage':
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action']) && $_POST['action'] === 'search') {
                    // Handle product search
                if (isset($_POST['name']) && !empty($_POST['name'])) {
                    $name = $_POST['name'];
                    $products = search_products($name);
                } else {
                        // If no search term is provided, show all products
                    $products = product_list();
                }
            } elseif (isset($_POST['action']) && $_POST['action'] === 'filter') {
                    // Handle category filter
                if (isset($_POST['category']) && !empty($_POST['category'])) {
                    $category = $_POST['category'];
                    $products = catalog_products($category);
                } else {
                        // If no category is selected, show all products
                    $products = product_list();
                }
            } else {
                    // If no valid action, show the main product listing
                $products = product_list();
            }
        } else {
                // No form submission, show the main product listing by default
            $products = product_list();
        }
        
            // Always include the userpage view
            include '../View/userpage.php';  // Show user-specific content
            break;
        



    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Check if the username and password have been provided
            if (isset($_POST['username']) && isset($_POST['password'])) {
                login();
            } else {
                exit();
            }
        } else {
            // If the form hasn't been submitted, show the login page
            include '../View/login.php';
        }
        break;
    case 'logout':
        logout();
        break;


    case 'signup':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Check if the username, password, and confirm password have been provided
            if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['confirm_password'])) {
                // Call the signup_processes function to handle the signup logic
                signup();
            } else {
                // Redirect back to signup with an error if any required fields are missing
                exit();
            }
        } else {
            // If the form hasn't been submitted, show the signup page
            include '../View/signup.php';
        }
        break;
    case 'cart':
        session_start();
        if (!isset($_SESSION['User_ID']) ||!isset($_SESSION['Email_Address'])) {
            // User is not logged in, redirect to homepage
            header('Location: index.php?action=default');
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action']) && $_POST['action'] === 'delete_item') {
                        // Handle item deletion from the cart
                delete_item();
            }
            elseif (isset($_POST['action']) && $_POST['action'] === 'update_item') {
                        // Handle item quantity update
                update_quantity();
            }
            elseif (isset($_POST['action']) && $_POST['action'] === 'clear_cart') {
                clear_cart();
            }
            else {
                addtocart();
            }
        } else {
            // If the form hasn't been submitted, show the cart page
            include '../View/cartpage.php';
        }
        break;
    case 'shipment':
        session_start();
        if (!isset($_SESSION['User_ID']) || !isset($_SESSION['Email_Address'])) {
            // User is not logged in, redirect to homepage
            header('Location: index.php?action=homepage');
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Check if all required fields are present and not empty
            if (isset($_POST['address']) && !empty($_POST['address']) &&
                isset($_POST['city']) && !empty($_POST['city']) &&
                isset($_POST['state']) && !empty($_POST['state']) &&
                isset($_POST['zipcode']) && !empty($_POST['zipcode'])) {
                
                // Call the function to validate and handle the address
                validateAddress();
            } else {
                // Redirect back to the shipping page with an error if any required fields are missing
                header("Location: index.php?action=shipment&error=" . urlencode("Please fill in all required fields."));
                exit();
            }
        } else {
            // If the form hasn't been submitted, show the shipping page
            include '../View/shippingpage.php';
        }
        break;

    case 'orderpage':
        session_start();
        if (!isset($_SESSION['User_ID'])) {
            header("Location: index.php?action=login&error=" . urlencode("Please log in to view your orders."));
            exit();
        }

        $userId = $_SESSION['User_ID'];
        $order = getUserOrders($userId);

        include '../View/orderpage.php'; // Load the order page view
        break;

    case 'admin':
        session_start();
        if (!isset($_SESSION['User_ID']) || !isset($_SESSION['Email_Address']) || $_SESSION['Role'] !== 'admin') {
            if (isset($_SESSION['Role']) && $_SESSION['Role'] === 'user') {
                // Redirect the regular user to the login page with an error and the redirect parameter
                header("Location: index.php?action=login&redirect=admin&error=" . urlencode("You do not have permission to access the admin panel."));
            } else {
                // If the user is not logged in at all, redirect to the login page with the redirect parameter
                header("Location: index.php?action=login&redirect=admin&error=" . urlencode("Please log in with an admin account to access the admin panel."));
            }
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['action']) && $_POST['action'] === 'add_product') {
                // Handle adding a new product
                add_product();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'add_user') {
                // Handle adding a new user
                add_user();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'update_product') {
                // Handle editing an existing product
                update_product();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'delete_product') {
                // Handle deleting a product
                delete_product();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'view_orders') {
                // Handle viewing orders
                $orders = view_orders();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'view_products') {
                // Handle viewing products
                $products = view_products();
            } elseif (isset($_POST['action']) && $_POST['action'] === 'view_customers') {
                // Handle viewing customers
                $customers = view_customers();
            }
        }
        include '../View/adminpage.php'; // Load the admin page view
        break;


            
            

    default:
        // Default behavior: show the homepage or handle form submissions
        session_start();
        if (!isset($_SESSION['User_ID']) || !isset($_SESSION['Email_Address'])) {
            header('Location: index.php?action=homepage');
        } else {
            // If the user is logged in, redirect to userpage
            header('Location: index.php?action=userpage');
            exit();
        }
        break;
}
?>
