<?php
// Redirect the user to the controller's index.php file
header("Location: controller/index.php");
exit();  // Stop further script execution
?>