
<?php 
include 'header.php'; ?>
<div class="login-text" style="display: flex; gap: 20px;">
    <a href="index.php?action=orderpage" class="login-border">Your Order</a>
    <a href="index.php?action=cart" class="login-border">Shopping Cart</a>
    <a href="index.php?action=logout" class="login-border">Logout</a>
</div>
<div class="function-wrapper">
    <div class="function-text">
        <!-- Search Filter Form -->
        <div class="search-product">
            <h2>Search Product</h2>
            <form method="POST" action="index.php?action=userpage">
                <input type="hidden" name="action" value="search"> <!-- Specify this is a search action -->
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" required>
                <button type="submit">Search</button>
            </form>
        </div>
        <!-- Category Filter Form -->
        <div class="catalog-filter">
            <h2>Filter by Category</h2>
            <form method="POST" action="index.php?action=userpage">
                <input type="hidden" name="action" value="filter"> <!-- Specify this is a filter action -->
                <label for="category">Select Category:</label>
                <select name="category" id="category">
                    <option value="">All Products</option> <!-- This option will show all products -->
                    <option value="Laptop">Laptops</option>
                    <option value="Phone">Phones</option>
                    <option value="Accessories">Accessories</option>
                    <option value="TV">TVs</option>
                </select>
                <button type="submit">Filter</button>
            </form>
        </div>
    </div>
</div>
<div class="container">
    <h1>Product On Sale</h1>
    <?php if (isset($_GET['error'])) {
                    echo '<p style="color: red;">' . htmlspecialchars(urldecode($_GET['error'])) . '</p>';
                }
                ?>
    <?php if (isset($_GET['success'])): ?>
                <p style="color: green;"><?= htmlspecialchars(urldecode($_GET['success'])); ?></p>
            <?php endif; ?>
    <div class="product-list">
        <?php
        if ($products && count($products) > 0) {
            // Loop through each product and display its details
            foreach ($products as $row) {
                echo '<div class="product">';
                echo '<img src="' . htmlspecialchars($row["Image"]) . '" alt="Product Image">';
                echo '<h3>' . htmlspecialchars($row["Name"]) . '</h3>';
                echo '<p>' . htmlspecialchars($row["Description"]) . '</p>';
                echo '<p class="price">$' . number_format($row["Price"], 2) . '</p>';
                
                echo '<form method="POST" action="index.php?action=cart">';
                echo '<input type="hidden" name="product_id" value="' . htmlspecialchars($row["Product_ID"]) . '">';
                echo '<input type="hidden" name="name" value="' . htmlspecialchars($row["Name"]) . '">';
                echo '<input type="hidden" name="price" value="' . htmlspecialchars($row["Price"]) . '">';

                // Quantity input
                echo '<label for="quantity">Quantity:</label>';
                echo '<input type="number" name="quantity" id="quantity" min="1" value="1" required>';

                // Buy button
                echo '<button type="submit" name="action_type" value="buy">Buy</button>';

                // Sell button
                echo '<button type="submit" name="action_type" value="sell">Sell</button>';

                echo '</form>';

                echo '</div>';
            }
        } else {
            echo "<p>No products found.</p>";
        }
        ?>
    </div>
</div>
<?php include 'footer.php'; ?>
