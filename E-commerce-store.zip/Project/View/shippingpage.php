    <?php include 'header.php'; ?>
    <div class="product-details">
        <h2>Information</h2>
        <p><strong>ID:</strong> <?php echo htmlspecialchars($_SESSION['User_ID']); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['Username']); ?></p>
        <p><strong>Email Address:</strong> <?php echo htmlspecialchars($_SESSION['Email_Address']); ?></p>
    </div>
    <h1>Shipping or Pickup Products Address</h1>
    <form method="POST" action="index.php?action=shipment">
        <label for="address">Street Address:</label>
        <input type="text" id="address" name="address" required>
        <br><br>

        <label for="city">City:</label>
        <input type="text" id="city" name="city" required>
        <br><br>

        <label for="state">State:</label>
        <input type="text" id="state" name="state" maxlength="2" required>
        <br><br>

        <label for="zipcode">ZIP Code:</label>
        <input type="text" id="zipcode" name="zipcode" maxlength="5" required>
        <br><br>

        <button type="submit">Submit</button>
    </form>

    <?php if (isset($_GET['error'])): ?>
                    <p style="color: red;"><?= htmlspecialchars(urldecode($_GET['error'])); ?></p>
                <?php endif; ?>
                <!-- Display Success Messages -->
                <?php if (isset($_GET['success'])): ?>
                    <p style="color: green;"><?= htmlspecialchars(urldecode($_GET['success'])); ?></p>
                <?php endif; ?>
    <?php include 'footer.php';
    ?>
