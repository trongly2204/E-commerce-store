<?php 
include 'header.php'; ?>
<div class="login-text">
    <a href="index.php?action=login" class="login-border">Login</a>
</div>
<div class="function-wrapper">
    <div class="function-text">
        <!-- Search Filter Form -->
        <div class="search-product">
            <h2>Search Product</h2>
            <form method="POST" action="index.php?action=homepage">
                <input type="hidden" name="action" value="search"> <!-- Specify this is a search action -->
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" required>
                <button type="submit">Search</button>
            </form>
        </div>
        <!-- Category Filter Form -->
        <div class="catalog-filter">
            <h2>Filter by Category</h2>
            <form method="POST" action="index.php?action=homepage">
                <input type="hidden" name="action" value="filter"> <!-- Specify this is a filter action -->
                <label for="category">Select Category:</label>
                <select name="category" id="category">
                    <option value="">All Products</option> <!-- This option will show all products -->
                    <option value="Laptop">Laptops</option>
                    <option value="Phone">Phones</option>
                    <option value="Accessories">Accessories</option>
                    <option value="TV">TVs</option>
                </select>
                <button type="submit">Filter</button>
            </form>
        </div>
    </div>
</div>
<div class="container">
        <h1>Product On Sale</h1>
        <div class="product-list">
            <?php
            if ($products && count($products) > 0) {
                // Loop through each product and display its details
                foreach ($products as $row) {
                    echo '<div class="product">';
                    echo '<img src="' . htmlspecialchars($row["Image"]) . '" alt="Product Image">';
                    echo '<h3>' . htmlspecialchars($row["Name"]) . '</h3>';
                    echo '<p>' . htmlspecialchars($row["Description"]) . '</p>';
                    echo '<p class="price">$' . number_format($row["Price"], 2) . '</p>';
                    echo '</div>';
                }
            } else {
                echo "<p>No products found.</p>";
            }
            ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>