<!DOCTYPE html>
<html lang="en">
    <head>
        <title> E-Commerce </title>
        <link rel="stylesheet" href="../style.css">
        </head>
    <body>
        <header>
            <h1>E-Commerce Store</h1>
            <nav>
                <ul>
                    <li><a href="index.php?action=homepage">Home Page</a></li>
                    <li><a href="index.php?action=admin">Admin Page</a></li>
                </ul>
            </nav>
            
        </header>
        </html>