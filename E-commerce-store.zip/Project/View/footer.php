<footer>
    <p>&copy; <?php echo date('Y'); ?> E-Commerce Store. All right reserved</p>
</footer>
