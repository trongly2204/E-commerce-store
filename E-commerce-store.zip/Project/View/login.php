<?php 
include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <h1>Welcome to Trong's Depot</h1>

    <div>
        <h2>Login</h2>
        <!-- Changed form action to send to index.php?action=login -->
        <form action="index.php?action=login" method="POST" class="login-form">
            <label for="username" class="login-label">Username</label>
            <input type="text" id="username" name="username" class="login-input" required>
            <br><br>
            <label for="password" class="login-label">Password</label>
            <input type="password" id="password" name="password" class="login-input" required>
            <br><br>

            <!-- If it direct from admin case, so it will add hidden value redirect == admin -->
            <?php if (isset($_GET['redirect']) && $_GET['redirect'] === 'admin'): ?>
                <input type="hidden" name="redirect" value="admin">
            <?php endif; ?>

            <!-- Display error message if any -->
            <?php if (isset($_GET['error'])): ?>
                <p style="color: red;"><?= htmlspecialchars(urldecode($_GET['error'])); ?></p>
            <?php endif; ?>
            <!-- Display Success Messages -->
            <?php if (isset($_GET['success'])): ?>
                <p style="color: green;"><?= htmlspecialchars(urldecode($_GET['success'])); ?></p>
            <?php endif; ?>
            <button type="submit" class="login-btn">Login</button>

        </form>
        <div class="login-signup-link">
            <p>Don't have an account? <a href="index.php?action=signup">Sign up</a></p>
        </div>
    </div>
</body>

<?php include 'footer.php';?>
</html>
