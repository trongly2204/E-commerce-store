<?php 
include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>signup</title>
</head>
<body>
    <h1>Welcome to Trong's Depot</h1>

    <div>
        <h2>Sign up</h2>
        <form action="index.php?action=signup" method="POST" class="login-form">
        <label for="username" class="login-label">Username:</label>
            <input type="text" id="username" name="username" class="login-input" required>
            <br><br>
            <label for="password" class="login-label">Password:</label>
            <input type="password" id="password" name="password" class="login-input" required>
            <br><br>
            <label for="confirm_password" class="login-label">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" class="login-input" required>
            <br><br>
            <label for="email" class="login-label">Email:</label>
            <input type="email" id="email" name="email" class="login-input" required>
            <br><br>
            <input type="submit" value="Sign up" class="login-button">
            <!-- Display Error Messages -->
            <?php if (isset($_GET['error'])): ?>
                <p style="color: red;"><?= htmlspecialchars(urldecode($_GET['error'])); ?></p>
            <?php endif; ?>
            <!-- Display Success Messages -->
            <?php if (isset($_GET['success'])): ?>
                <p style="color: green;"><?= htmlspecialchars(urldecode($_GET['success'])); ?></p>
            <?php endif; ?>
            
        </form>
        <div class="login-signup-link">
            <p>Already have an account? <a href="index.php?action=login">Log in</a></p>
        </div>
        </div>
</body>
<?php include 'footer.php'; ?>
</html>