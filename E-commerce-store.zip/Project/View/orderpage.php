<?php 
include 'header.php'; 
?>
<h1>Your Order History</h1>
<table>
    <tr>
        <th>Order ID</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Date</th>
        <th>Total Amount</th>
    </tr>
    <?php
    // Check if there are orders to display
    if (isset($order) && count($order) > 0) {
        // Loop through each order and display its details
        foreach ($order as $row) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row["Order_ID"]) . '</td>';
            echo '<td>' . htmlspecialchars($row["Product_Name"]) . '</td>';
            echo '<td>' . htmlspecialchars($row["Quantity"]) . '</td>';
            echo '<td>$' . number_format($row["Amount"], 2) . '</td>';
            echo '<td>' . htmlspecialchars($row["Order_Date"]) . '</td>';
            echo '<td>$' . number_format($row["Total_Amount"], 2) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6">No order history found.</td></tr>';
    }
    ?>
</table>

<?php include 'footer.php'; ?>
