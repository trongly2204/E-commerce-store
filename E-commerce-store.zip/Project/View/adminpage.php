<?php
include 'header.php';
?>

<h1>Admin Page</h1>
<div class="login-text" style="display: flex; gap: 20px;">
    <a href="index.php?action=logout" class="login-border">Logout</a>
</div>
<a href="index.php?action=admin&view=add_product">Add Product</a>
<a href="index.php?action=admin&view=add_user">Add User</a>
<a href="index.php?action=admin&view=update_product">Update Product</a>
<a href="index.php?action=admin&view=delete_product">Delete Product</a>
<a href="index.php?action=admin&view=order_list">Order List</a>
<a href="index.php?action=admin&view=customer_list">Customer List</a>
<a href="index.php?action=admin&view=product_list">Product List</a>


<?php
// Handle different views based on the 'view' parameter
if (isset($_GET['view'])) {
    switch ($_GET['view']) {
        case 'add_product':
            // Form to add a new product
            echo "<h2>Add Product</h2>";
            ?>
            <form action="index.php?action=admin&view=add_product" method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_product">
                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" required><br><br>

                <label for="price">Price:</label>
                <input type="number" id="price" name="price" step="0.01" required><br><br>

                <label for="stock">Stock:</label>
                <input type="number" id="stock" name="stock" required><br><br>

                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="Laptop">Laptop</option>
                    <option value="Phone">Phone</option>
                    <option value="Accessories">Accessories</option>
                    <option value="TV">TV</option>
                </select><br><br>

                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea><br><br>

                <label for="image">Insert image:</label>
                <input type="file" id="image" name="image" required><br><br>


                <input type="submit" value="Add Product">
            </form>
            <?php
            break;

        case 'add_user':
            // Form to add a new user
            echo "<h2>Add User</h2>";
            ?>
            <form action="index.php?action=admin&view=add_user" method="post">
                <input type="hidden" name="action" value="add_user">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required><br><br>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required><br><br>

                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required><br><br>

                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select><br><br>

                <input type="submit" value="Add User">
            </form>
            <?php
            break;

        case 'update_product':
            echo "<h2>Update Product</h2>";

            // Fetch all products to create a dropdown for selection
            $products = view_products(); // Assuming view_products() fetches all products
            ?>
            <form action="index.php?action=admin&view=update_product" method="post">
                <label for="product_id">Select Product to Update:</label>
                <select id="product_id" name="product_id" required onchange="this.form.submit()">
                    <option value="">-- Select a Product --</option>
                    <?php foreach ($products as $product): ?>
                        <option value="<?php echo htmlspecialchars($product['Product_ID']); ?>">
                            <?php echo htmlspecialchars($product['Name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            <?php

            // Check if a product ID is selected and fetch its details
            if (isset($_POST['product_id'])) {
                $product_id = (int)$_POST['product_id'];
                $product = get_product_by_id($product_id); // Function to fetch product details by ID

                if ($product) {
                    ?>
                    <form action="index.php?action=admin&view=update_product" method="post">
                        <input type="hidden" name="action" value="update_product">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['Product_ID']); ?>">

                        <label for="name">Product Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['Name']); ?>"><br><br>

                        <label for="price">Price:</label>
                        <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($product['Price']); ?>"><br><br>

                        <label for="stock">Stock:</label>
                        <input type="number" id="stock" name="stock" value="<?php echo htmlspecialchars($product['Stock']); ?>"><br><br>


                        <label for="category">Category:</label>
                        <select id="category" name="category">
                            <option value="Laptop" <?php if ($product['Category'] === 'Laptop') echo 'selected'; ?>>Laptop</option>
                            <option value="Phone" <?php if ($product['Category'] === 'Phone') echo 'selected'; ?>>Phone</option>
                            <option value="Accessories" <?php if ($product['Category'] === 'Accessories') echo 'selected'; ?>>Accessories</option>
                            <option value="TV" <?php if ($product['Category'] === 'TV') echo 'selected'; ?>>TV</option>
                        </select><br><br>

                        <label for="description">Description:</label>
                        <textarea id="description" name="description"><?php echo htmlspecialchars($product['Description']); ?></textarea><br><br>
                        <input type="submit" value="Update Product">
                    </form>
                    <?php
                } else {
                    echo "<p>Product not found.</p>";
                }
            }
            break;



        case 'delete_product':
            echo "<h2>Delete Product</h2>";

            // Fetch all products to create a dropdown for selection
            $products = view_products(); // Assuming view_products() fetches all products
            ?>
            <form action="index.php?action=admin&view=delete_product" method="post">
                <input type="hidden" name="action" value="delete_product">

                <label for="product_id">Select Product to Delete:</label>
                <select id="product_id" name="product_id" required>
                    <option value="">-- Select a Product --</option>
                    <?php foreach ($products as $product): ?>
                        <option value="<?php echo htmlspecialchars($product['Product_ID']); ?>">
                            <?php echo htmlspecialchars($product['Name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select><br><br>

                <input type="submit" value="Delete Product">
            </form>
            <?php
            break;


        case 'order_list':
            // Display the list of orders
            echo "<h2>Order List</h2>";
            $orders = view_orders();
            if (count($orders) > 0) {
                echo "<table border='1'>";
                echo "<tr><th>Order ID</th><th>User ID</th><th>Quantity</th><th>Order Date</th><th>Amount</th><th>Transaction Type</th><th>Product Name</th><th>Address</th></tr>";
                foreach ($orders as $order) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($order['Order_ID']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['User_ID']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['Quantity']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['Order_Date']) . "</td>";
                    echo "<td>$" . number_format($order['Amount'], 2) . "</td>";
                    echo "<td>" . htmlspecialchars($order['Transaction_Type']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['Product_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['Address']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No orders found.</p>";
            }
            break;

        case 'customer_list':
            // Display the list of customers
            echo "<h2>Customer List</h2>";
            $customers = view_customers();
            if (count($customers) > 0) {
                echo "<table border='1'>";
                echo "<tr><th>User ID</th><th>Username</th><th>Email Address</th><th>Role</th></tr>";
                foreach ($customers as $customer) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($customer['User_ID']) . "</td>";
                    echo "<td>" . htmlspecialchars($customer['Username']) . "</td>";
                    echo "<td>" . htmlspecialchars($customer['Email_Address']) . "</td>";
                    echo "<td>" . htmlspecialchars($customer['Role']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No customers found.</p>";
            }
            break;

        case 'product_list':
            // Display the list of products
            echo "<h2>Product List</h2>";
            $products = view_products();
            if (count($products) > 0) {
                echo "<table border='1'>";
                echo "<tr><th>Product ID</th><th>Name</th><th>Price</th><th>Stock</th><th>Category</th><th>Description</th></tr>";
                foreach ($products as $product) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($product['Product_ID']) . "</td>";
                    echo "<td>" . htmlspecialchars($product['Name']) . "</td>";
                    echo "<td>$" . number_format($product['Price'], 2) . "</td>";
                    echo "<td>" . htmlspecialchars($product['Stock']) . "</td>";
                    echo "<td>" . htmlspecialchars($product['Category']) . "</td>";
                    echo "<td>" . htmlspecialchars($product['Description']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No products found.</p>";
            }
            break;

        default:
            echo "<p>Welcome to the Admin Page. Please select an action from the menu.</p>";
            break;
    }
}
?>
<?php if (isset($_GET['error'])): ?>
                            <p style="color: red;"><?= htmlspecialchars(urldecode($_GET['error'])); ?></p>
                        <?php endif; ?>
                        <?php if (isset($_GET['success'])): ?>
                            <p style="color: green;"><?= htmlspecialchars(urldecode($_GET['success'])); ?></p>
                        <?php endif; ?>
<?php
include 'footer.php';
?>
