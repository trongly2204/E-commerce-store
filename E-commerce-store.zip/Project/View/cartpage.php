<?php 
include 'header.php'; ?>
<div class="product-details">
<h2>Information</h2>
        <p><strong>ID:</strong> <?php echo htmlspecialchars($_SESSION['User_ID']); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['Username']);?></p>
        <p><strong>Email Address:</strong> <?php echo htmlspecialchars($_SESSION['Email_Address']); ?></p>
</div>
<h1>Your Cart Products</h1>
<table>
    <tr>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Action</th>
    </tr>
    <?php 
    $total_price = 0;
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        foreach ($_SESSION['cart'] as $product) {
            $quantity = isset($product['Quantity']) ? $product['Quantity'] : 1;
            echo '<tr>';
            echo '<td>' . htmlspecialchars($product['Name']) . '</td>';  
            echo '<td>' . $quantity . '</td>';
            echo '<td>$' . number_format($product['Price'], 2) . '</td>';  
            echo '<td>' . htmlspecialchars($product['Transaction_Type']) . '</td>';  
            ?>
            <td>
                <form method="POST" action="index.php?action=cart" style="display:inline;">
                    <input type="hidden" name="action" value="update_item">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['Product_ID']); ?>">
                    <input type="number" name="quantity" value="<?php echo $quantity; ?>" min="1">
                    <button type="submit">Update</button>
                </form>
                <form method="POST" action="index.php?action=cart" style="display:inline;">
                    <input type="hidden" name="action" value="delete_item">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['Product_ID']); ?>">
                    <button type="submit">Delete</button>
                </form>
                <?php if (isset($_GET['error'])): ?>
                    <p style="color: red;"><?= htmlspecialchars(urldecode($_GET['error'])); ?></p>
                <?php endif; ?>
                </td>
            <?php
            echo '</tr>';
        }
        echo '<tr><td colspan="3">Total Quantity:</td><td>' . number_format($_SESSION['cart_totals']['total_quantity']) . '</td></tr>';
        echo '<tr><td colspan="3">Total Price:</td><td>$' . number_format($_SESSION['cart_totals']['total_price'], 2) . '</td></tr>';
    } else {
        echo '<tr><td colspan="4">No products in the cart.</td></tr>';
    }
    ?>
</table>
<br>
<form method="POST" action="index.php?action=cart" >
    <input class="login-border" type="hidden" name="action" value="clear_cart">
    <button type="submit" class="login-border">Empty Cart</button>
</form>
<br>
<form method="POST" action="index.php?action=shipment" class="login-text">
    <input class="login-border" type="hidden" name="action" value="pay">
    <button type="submit" class="login-border">Pay</button>
</form>

<?php include 'footer.php'; ?>